#!/bin/bash

python scripts/generate.py -s gl.xml -d ../source/glbinding -r gl.revision -p patch.xml
