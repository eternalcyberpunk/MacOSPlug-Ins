/**
 * \namespace glbinding
 *
 * \brief Contains all the classes of glbinding.
 *
 * TODO: Detailed documentation for glbinding here.
 */
 