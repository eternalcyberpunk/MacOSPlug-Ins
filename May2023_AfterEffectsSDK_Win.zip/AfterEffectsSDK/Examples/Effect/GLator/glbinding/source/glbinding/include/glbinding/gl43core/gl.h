#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl43core/types.h>
#include <glbinding/gl43core/boolean.h>
#include <glbinding/gl43core/values.h>
#include <glbinding/gl43core/bitfield.h>
#include <glbinding/gl43core/enum.h>
#include <glbinding/gl43core/functions.h>
