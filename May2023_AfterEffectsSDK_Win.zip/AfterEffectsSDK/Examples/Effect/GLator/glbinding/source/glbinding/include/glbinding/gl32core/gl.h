#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl32core/types.h>
#include <glbinding/gl32core/boolean.h>
#include <glbinding/gl32core/values.h>
#include <glbinding/gl32core/bitfield.h>
#include <glbinding/gl32core/enum.h>
#include <glbinding/gl32core/functions.h>
