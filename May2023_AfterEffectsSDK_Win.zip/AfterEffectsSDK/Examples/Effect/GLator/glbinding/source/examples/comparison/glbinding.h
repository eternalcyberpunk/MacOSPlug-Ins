#pragma once

void glbinding_init();
void glbinding_test();

void glbinding_error(bool enable);
